

<?php $__env->startSection('title'); ?>
    Riwayat
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <div class="col-12 table-responsive">
        <table class="table table-striped" id="example1">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Order ID</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td><a href="<?php echo e(route('user.history.detail', $item['order_id'])); ?>"><?php echo e($item['order_id']); ?></a></td>
                        <?php
                            $color = '';
                            $status = '';
                            switch ($item['status']) {
                                case 1:
                                    $status = 'UNVERIFIED';
                                    $color = 'warning';
                                    break;
                                case 2:
                                    $status = 'VERIFIED';
                                    $color = 'success';
                                    break;
                                case 3:
                                    $status = 'EXPIRED';
                                    $color = 'danger';
                                    break;
                                default:
                                    # code...
                                    break;
                            }
                        ?>
                        <td>
                            <div class="badge badge-<?php echo e($color); ?>">
                                <?php echo e($status); ?></div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <a type="button" class="btn btn-secondary" href="<?php echo e(route('user.home')); ?>"><i class="fas fa-arrow-left"></i> Kembali</a>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/dataTables.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/responsive.bootstrap4.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/responsive.bootstrap4.min.js')); ?>"></script>
    <script>
        $(function() {
            $("#example1").DataTable({
                "responsive": true,
                "lengthChange": false,
                "autoWidth": false,
            })
        });
    </script>
    <script>
        function confirmDelete() {
            return confirm('Apakah anda yakin?');
        }


        $(document).ready(function() {
            // let jumlah = $("#jumlah").text()
            // let hari = $(".hari").val()
            // let harga = $("#harga").text()
            // $("#total").text(jumlah * hari)
            // $("#grandtotal").text(jumlah * hari *harga)
            calculate()

            $(".hari").change(function() {
                calculate();
                // let jumlah = $("#jumlah").text()
                // let hari = $(".hari").val()
                // let harga = $("#harga").text()
                // $("#total").text(jumlah * hari)
                // $("#grandtotal").text(jumlah * hari *harga)
            });
        });

        function calculate() {
            let jumlah = $("#jumlah").text()
            let hari = $(".hari").val()
            let harga = $("#harga").text()
            $("#total").text(jumlah * hari)
            $("#grandtotal").text(jumlah * hari * harga)
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\coding\laragon\www\051-Arief-Rahman\elibrary\resources\views/user/history/index.blade.php ENDPATH**/ ?>