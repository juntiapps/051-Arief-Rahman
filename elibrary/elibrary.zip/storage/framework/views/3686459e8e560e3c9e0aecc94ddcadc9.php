

<?php $__env->startSection('title'); ?>
    Check Out
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <form action="<?php echo e(route('user.sendcheckout')); ?>" method="post" onsubmit="return confirmDelete()">
        <?php echo csrf_field(); ?>
        <input type="hidden" name='order_id' value="<?php echo e($order_id); ?>">
        <input type="hidden" name='tr_id' value="<?php echo e($tr_id); ?>">
        <div class="p-1 m-1">
            <h4>Order ID: #<?php echo e($order_id); ?></h4>
        </div>
        <div class="col-12 table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Judul</th>
                        <th>Pengarang</th>
                        <th>Tahun</th>
                        <th>Jumlah</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td><?php echo e($item['title']); ?></td>
                            <td><?php echo e($item['author']); ?></td>
                            <td><?php echo e($item['year']); ?></td>
                            <td><?php echo e($item['jumlah']); ?></td>
                            <td>
                                <a href="<?php echo e(route('user.delcheckout', $item['id'])); ?>" class="btn btn-danger btm-sm"
                                    onclick="return confirmDelete()">Hapus</a>
                            </td>
                        <tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th colspan="4" class="text-right">Jumlah</th>
                        <th id='jumlah'><?php echo e(count($carts)); ?></th>
                    </tr>
                    <tr>
                        <th colspan="4" class="text-right">Lama Pinjam</th>
                        <th>
                            <div class="row align-items-center">
                                <input type="number" name='hari' value='2' style="width: 50px;" class="hari mr-2"
                                    min="2" />hari
                            </div>
                        </th>
                    </tr>
                    <tr>
                        <th colspan="4" class="text-right">Total</th>
                        <th>
                            <div class="row ">
                                <div id='total'></div>
                                <div class="mx-2">x Rp.</div>
                                <div id='harga'><?php echo e($harga); ?></div>
                                <div class="mx-2">= Rp. </div>
                                <div id='grandtotal' class="font-weight-bold"></div>
                            </div>
                        </th>
                    </tr>
                </tfoot>
            </table>
        </div>
<a type="button" class="btn btn-secondary" href="<?php echo e(route('user.home')); ?>"><i class="fas fa-arrow-left"></i> Kembali</a>

        <button type="submit" class="btn btn-primary "><i class="fas fa-cart-plus"></i> Kirim</button>

    </form>
    
    
    
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/dataTables.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/responsive.bootstrap4.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
    
    <script>
        function confirmDelete() {
            return confirm('Apakah anda yakin?');
        }


        $(document).ready(function() {
            // let jumlah = $("#jumlah").text()
            // let hari = $(".hari").val()
            // let harga = $("#harga").text()
            // $("#total").text(jumlah * hari)
            // $("#grandtotal").text(jumlah * hari *harga)
            calculate()

            $(".hari").change(function() {
                calculate();
                // let jumlah = $("#jumlah").text()
                // let hari = $(".hari").val()
                // let harga = $("#harga").text()
                // $("#total").text(jumlah * hari)
                // $("#grandtotal").text(jumlah * hari *harga)
            });
        });

        function calculate() {
            let jumlah = $("#jumlah").text()
            let hari = $(".hari").val()
            let harga = $("#harga").text()
            $("#total").text(jumlah * hari)
            $("#grandtotal").text(jumlah * hari * harga)
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\coding\laragon\www\051-Arief-Rahman\elibrary\resources\views/user/checkout.blade.php ENDPATH**/ ?>