<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <title>ELibrary | <?php echo $__env->yieldContent('title'); ?></title>

    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(asset('css/fontawesome-free/all.min.css')); ?>">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(asset('/css/adminlte.min.css')); ?>">
    
    <?php echo $__env->yieldPushContent('css'); ?>
</head>

<body class="hold-transition layout-top-nav">
    <!-- Site wrapper -->
    <div class="wrapper">
        <!-- Navbar -->
        <nav class="main-header navbar navbar-expand-md navbar-white navbar-light">
            <!-- Left navbar links -->
            <div class="container">
                <ul class="navbar-nav">
                    <a href="<?php echo e(route('user.home')); ?>" class="navbar-brand">
                        <img src="<?php echo e(asset('img/logo.png')); ?>" alt="Elibrary Logo"
                            class="brand-image img-circle elevation-3" style="opacity: .8">

                        <span class="brand-text font-weight-light">ELibrary</span>
                    </a>
                    
                    
                </ul>
            </div>


            <!-- Right navbar links -->
            <ul class="navbar-nav ml-auto">
                <!-- Navbar Search -->
                

                <!-- Messages Dropdown Menu -->
                
                <!-- keranjang -->
                <li class="nav-item dropdown">
                    <a class="nav-link" data-toggle="dropdown" href="#">
                        <i class="fas fa-shopping-cart"></i>
                        <?php if(count($carts) > 0): ?>
                            <span class="badge badge-primary navbar-badge"><?php echo e(count($carts)); ?></span>
                        <?php endif; ?>
                    </a>
                    <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
                        <?php $__empty_1 = true; $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <a href="#" class="dropdown-item">
                                <div class="media align-items-center">
                                    <img src="<?php echo e($item['cover']); ?>" alt="<?php echo e($item['title']); ?>"
                                        class="img-size-50 mr-3 img-circle"
                                        style="object-fit: cover;height:50px;width:50px">
                                    <div class="media-body">
                                        <h3 class="dropdown-item-title">
                                            <?php echo e($item['title']); ?>

                                        </h3>
                                    </div>
                                </div>
                            </a>
                            <div class="dropdown-divider"></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p>Keranjang Kosong</p>
                        <?php endif; ?>
                        <a href="<?php echo e(route('user.checkout')); ?>" class="dropdown-item">
                            <i class="far fa-money-bill-alt"></i> Check Out
                        </a>
                    </div>
                </li>
                <!-- user menu -->
                <li class="nav-item dropdown">
                    <a class="nav-link" data-toggle="dropdown" href="#">
                        <i class="far fa-user-circle"></i>
                        
                    </a>
                    <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
                        <span class="dropdown-item dropdown-header">Hello, <?php echo e($username); ?></span>
                        <div class="dropdown-divider"></div>
                        <a href="<?php echo e(route('user.history')); ?>" class="dropdown-item">
                            <i class="fas fa-history mr-2"></i> Riwayat
                        </a>
                        <div class="dropdown-divider"></div>

                        <a href="<?php echo e(route('auth.logout')); ?>" class="dropdown-item">
                            <i class="fas fa-power-off mr-2"></i> Keluar
                        </a>
                    </div>
                </li>
            </ul>
        </nav>
        <!-- /.navbar -->

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <div class="container">
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <div class="container-fluid">
                        <div class="row mb-2">
                            <div class="col-sm-6">
                                <h1><?php echo $__env->yieldContent('title'); ?></h1>
                            </div>
                            
                        </div>
                    </div><!-- /.container-fluid -->
                </section>

                <!-- Main content -->
                <section class="content">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-12">
                                <?php echo $__env->yieldContent('content'); ?>
                                <!-- Default box -->
                                
                                <!-- /.card -->
                            </div>
                        </div>
                    </div>
                </section>
                <!-- /.content -->
            </div>

        </div>
        <!-- /.content-wrapper -->

        <footer class="main-footer">
            <div class="float-right d-none d-sm-block">
                <b>Version</b> 1.0.0
            </div>
            <strong>Copyright &copy; 2024 <a href="https://adminlte.io">ELibrary</a>.</strong> All rights
            reserved.
        </footer>

        <!-- Control Sidebar -->
        <aside class="control-sidebar control-sidebar-dark">
            <!-- Control sidebar content goes here -->
        </aside>
        <!-- /.control-sidebar -->
    </div>
    <!-- ./wrapper -->

    <!-- jQuery -->
    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
    <!-- Bootstrap 4 -->
    <script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>
    <!-- AdminLTE App -->
    <script src="<?php echo e(asset('js/adminlte.min.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('js'); ?>
    <!-- AdminLTE for demo purposes -->
    
</body>

</html>
<?php /**PATH D:\coding\laragon\www\051-Arief-Rahman\elibrary\resources\views/layout/app2.blade.php ENDPATH**/ ?>