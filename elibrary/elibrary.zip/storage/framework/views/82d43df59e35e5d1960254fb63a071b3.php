

<?php $__env->startSection('title'); ?>
    Edit Kategori
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('admin.categories.update', $category->id)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-group">
            <label for="id_buku">ID Kategori:</label>
            <input type="text" class="form-control" name="id" value="<?php echo e($category->id); ?>" disabled>
        </div>
        <div class="form-group">
            <label for="nama_buku">Nama Kategori:</label>
            <input type="text" class="form-control" name="name" value="<?php echo e($category->name); ?>" required>
        </div>

        <button type="submit" class="btn btn-success"><i class="fas fa-save"></i> Update</button>
        <a type="button" class="btn btn-danger" href="<?php echo e(url()->previous()); ?>"><i class="fas fa-times"></i> Batal</a>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/dataTables.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/responsive.bootstrap4.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/responsive.bootstrap4.min.js')); ?>"></script>
    <script>
        $(function() {
            $("#example1").DataTable({
                "responsive": true,
                "lengthChange": false,
                "autoWidth": false,
            })
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\coding\laragon\www\051-Arief-Rahman\elibrary\resources\views/admin/categories/edit.blade.php ENDPATH**/ ?>