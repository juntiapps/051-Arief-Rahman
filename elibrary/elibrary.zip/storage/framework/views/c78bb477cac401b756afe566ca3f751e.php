<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>E-Library | Log in</title>

    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(asset('css/fontawesome-free/all.min.css')); ?>">
    <!-- icheck bootstrap -->
    <link rel="stylesheet" href="<?php echo e(asset('css/icheck-bootstrap/icheck-bootstrap.min.css')); ?>">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(asset('/css/adminlte.min.css')); ?>">
    <style>
        body {
    background-image: url('<?php echo e(asset("img/login_back.jpg")); ?>');
    background-size: cover; /* Ensures the image covers the entire container */
    background-repeat: no-repeat; /* Prevents the image from repeating */
    background-position: bottom center; /* Vertically aligns the image to the bottom */
    height: 100vh; /* Adjust height as needed */
}
    </style>
</head>

<body class="hold-transition login-page">
    <div class="login-box">
        <!-- /.login-logo -->
        <div class="card card-outline card-primary">
            <div class="p-2 text-center"><img src="<?php echo e(asset('img/logo.png')); ?>" alt="Elibrary Logo"
                    class="brand-image img-circle elevation-3" style="opacity: .8;height:80px;width:80px"></div>

            <div class="card-header text-center">
                <a href="" class="h1"><b>E</b>Library</a>
            </div>
            <div class="card-body">
                <p class="login-box-msg">Silakan Masuk</p>

                <?php if(session()->get('error')): ?>
                    <p style="color: red"><?php echo e(session()->get('error')); ?></p>
                <?php endif; ?>

                <form action="<?php echo e(route('auth.login')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="input-group mb-3">
                        <input type="email" class="form-control" placeholder="Email" name="email">
                        <div class="input-group-append">
                            <div class="input-group-text">
                                <span class="fas fa-envelope"></span>
                            </div>
                        </div>
                    </div>
                    <div class="input-group mb-3">
                        <input type="password" class="form-control" placeholder="Password" name="password">
                        <div class="input-group-append">
                            <div class="input-group-text">
                                <span class="fas fa-lock"></span>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-8">
                            
                        </div>
                        <!-- /.col -->
                        <div class="col-4">
                            <button type="submit" class="btn btn-primary btn-block">Masuk</button>
                        </div>
                        <!-- /.col -->
                    </div>
                </form>

                
            </div>
            <!-- /.card-body -->
        </div>
        <!-- /.card -->
    </div>
    <!-- /.login-box -->

    <!-- jQuery -->
    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
    <!-- Bootstrap 4 -->
    <script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>
    <!-- AdminLTE App -->
    <script src="<?php echo e(asset('js/adminlte.min.js')); ?>"></script>
</body>

</html>
<?php /**PATH D:\coding\laragon\www\051-Arief-Rahman\elibrary\resources\views/auth/login.blade.php ENDPATH**/ ?>