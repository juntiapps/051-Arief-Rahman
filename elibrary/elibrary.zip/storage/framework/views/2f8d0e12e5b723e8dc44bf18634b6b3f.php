

<?php $__env->startSection('title'); ?>
    Detail Anggota
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <table class="table">
        <tbody>
            <tr>
                <th>ID Anggota</th>
                <td><?php echo e($user->id); ?></td>
            </tr>
            <tr>
                <th>Nama Anggota</th>
                <td><?php echo e($user->name); ?></td>
            </tr>
            <tr>
                <th>Email Anggota</th>
                <td><?php echo e($user->email); ?></td>
            </tr>
            <tr>
                <th>Peran</th>
                <td><?php echo e($user->role); ?></td>
            </tr>

        </tbody>
    </table>
    <a type="button" class="btn btn-success" href="<?php echo e(url()->previous()); ?>"><i class="fas fa-arrow-left"></i> Kembali</a>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/dataTables.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/responsive.bootstrap4.min.css')); ?>">
    <style>
        .tabb {
            display: inline-block;
            width: :200px
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/responsive.bootstrap4.min.js')); ?>"></script>
    <script>
        $(function() {
            $("#example1").DataTable({
                "responsive": true,
                "lengthChange": false,
                "autoWidth": false,
            })
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\coding\laragon\www\051-Arief-Rahman\elibrary\resources\views/admin/users/show.blade.php ENDPATH**/ ?>