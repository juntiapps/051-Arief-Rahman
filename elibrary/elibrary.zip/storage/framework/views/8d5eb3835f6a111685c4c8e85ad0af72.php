

<?php $__env->startSection('title'); ?>
    Detail Buku
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-auto"> <img src="<?php echo e($book['cover']); ?>" alt="<?php echo e($book['cover']); ?>" class="img-thumbnail" loading='lazy' width="210" height="290"></div>
    <div class="col">
        <table class="table">
            <tbody>
                <tr>
                    <th>ID Buku</th>
                    <td><?php echo e($book['id']); ?></td>
                </tr>
                <tr>
                    <th>Judul Buku</th>
                    <td><?php echo e($book['title']); ?></td>
                </tr>
                <tr>
                    <th>Sinopsis</th>
                    <td><?php echo e($book['synopsis']); ?></td>
                </tr>
                <tr>
                    <th>Pengarang</th>
                    <td><?php echo e($book['author']); ?></td>
                </tr>
                <tr>
                    <th>Tahun</th>
                    <td><?php echo e($book['year']); ?></td>
                </tr>
                <tr>
                    <th>Penerbit</th>
                    <td><?php echo e($book['publisher']); ?></td>
                </tr>
                <tr>
                    <th>Kategori</th>
                    <td><?php echo e($book['category']); ?></td>
                </tr>
                <tr>
                    <th>Stok</th>
                    <td><?php echo e($book['stock']); ?></td>
                </tr>
            </tbody>
        </table>
    </div>
</div>



<form action="<?php echo e(route('user.addtocart')); ?>" method="post" onsubmit="return confirmDelete()">
    <?php echo csrf_field(); ?>
    <input type="hidden" value="<?php echo e($book->id); ?>" name="book_id"/>
    <input type="hidden" value="<?php echo e($user_id); ?>" name="user_id"/>
<a type="button" class="btn btn-secondary" href="<?php echo e(url()->previous()); ?>"><i class="fas fa-arrow-left"></i> Kembali</a>
<button type="submit" class="btn btn-primary" <?php if($book['stock']==0): echo 'disabled'; endif; ?>><i class="fas fa-cart-plus" ></i> Tambahkan ke Keranjang</button>
</form>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/dataTables.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/responsive.bootstrap4.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
    
    <script>
        function confirmDelete() {
            return confirm('Apakah anda yakin?');
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\coding\laragon\www\051-Arief-Rahman\elibrary\resources\views/user/detail.blade.php ENDPATH**/ ?>