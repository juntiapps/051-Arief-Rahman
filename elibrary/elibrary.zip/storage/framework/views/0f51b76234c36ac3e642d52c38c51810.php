

<?php $__env->startSection('title'); ?>
    Detail Buku
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-auto"> <img src="<?php echo e($book['cover']); ?>" alt="<?php echo e($book['cover']); ?>" class="img-thumbnail" loading='lazy' width="210" height="290"></div>
        <div class="col">
            <table class="table">
                <tbody>
                    <tr>
                        <th>ID Buku</th>
                        <td><?php echo e($book['id']); ?></td>
                    </tr>
                    <tr>
                        <th>Judul Buku</th>
                        <td><?php echo e($book['title']); ?></td>
                    </tr>
                    <tr>
                        <th>Sinopsis</th>
                        <td><?php echo e($book['synopsis']); ?></td>
                    </tr>
                    <tr>
                        <th>Pengarang</th>
                        <td><?php echo e($book['author']); ?></td>
                    </tr>
                    <tr>
                        <th>Tahun</th>
                        <td><?php echo e($book['year']); ?></td>
                    </tr>
                    <tr>
                        <th>Penerbit</th>
                        <td><?php echo e($book['publisher']); ?></td>
                    </tr>
                    <tr>
                        <th>Kategori</th>
                        <td><?php echo e($book['category']); ?></td>
                    </tr>
                    <tr>
                        <th>Stok</th>
                        <td><?php echo e($book['stock']); ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>


    
    <a type="button" class="btn btn-success" href="<?php echo e(url()->previous()); ?>"><i class="fas fa-arrow-left"></i> Kembali</a>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/dataTables.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/responsive.bootstrap4.min.css')); ?>">
    <style>
        .tabb {
            display: inline-block;
            width: :200px
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/responsive.bootstrap4.min.js')); ?>"></script>
    <script>
        $(function() {
            $("#example1").DataTable({
                "responsive": true,
                "lengthChange": false,
                "autoWidth": false,
            })
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\coding\laragon\www\051-Arief-Rahman\elibrary\resources\views/admin/books/show.blade.php ENDPATH**/ ?>