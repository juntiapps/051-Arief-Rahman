

<?php $__env->startSection('title'); ?>
    Tambah Buku
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <form action="<?php echo e(route('admin.books.store')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="nama_buku">Judul:</label>
            <input type="text" class="form-control" id="nama_buku" name="title" required>
        </div>
        <div class="form-group">
            <label for="nama_buku">Sinopsis:</label>
            <textarea type="text" class="form-control" id="synopsis" name="synopsis" required></textarea>
        </div>
        <div class="form-group">
            <label for="pengarang">Pengarang:</label>
            <input type="text" class="form-control" id="pengarang" name="author" required>
        </div>
        <div class="form-group">
            <label for="stok">Tahun:</label>
            <input type="number" class="form-control" id="tahun" name="year" required>
        </div>
        <div class="form-group">
            <label for="pengarang">Penerbit:</label>
            <input type="text" class="form-control" id="penerbit" name="publisher" required>
        </div>
        <div class="form-group">
            <label for="kategori">Kategori:</label>
            
            <div class="row">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-2">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="categories[]" value="<?php echo e($category->id); ?>">
                            <label class="form-check-label">
                                <?php echo e($category->name); ?>

                            </label>
                        </div>
                    </div>
                    <?php if(($index + 1) % 6 == 0): ?>
            </div>
            <div class="row">
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="form-group">
                <label for="stok">Stok:</label>
                <input type="number" class="form-control" id="stok" name="stock" required>
            </div>
            <div class="form-group">
                <label for="pengarang">URL Cover:</label>
                <input type="text" class="form-control" id="cover" name="cover" required>
            </div>
            

            <button type="submit" class="btn btn-success"><i class="fas fa-save"></i> Simpan</button>
            <a type="button" class="btn btn-danger" href="<?php echo e(url()->previous()); ?>"><i class="fas fa-times"></i> Batal</a>

    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/dataTables.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/responsive.bootstrap4.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/responsive.bootstrap4.min.js')); ?>"></script>
    <script>
        $(function() {
            $("#example1").DataTable({
                "responsive": true,
                "lengthChange": false,
                "autoWidth": false,
            })
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\coding\laragon\www\051-Arief-Rahman\elibrary\resources\views/admin/books/add.blade.php ENDPATH**/ ?>