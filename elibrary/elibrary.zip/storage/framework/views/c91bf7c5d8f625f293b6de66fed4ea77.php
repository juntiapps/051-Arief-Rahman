

<?php $__env->startSection('title'); ?>
    Detail Kategori
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <table class="table">
        <tbody>
            <tr>
                <th>ID Kategori</th>
                <td><?php echo e($category->id); ?></td>
            </tr>
            <tr>
                <th>Nama Kategori</th>
                <td><?php echo e($category->name); ?></td>
            </tr>
        </tbody>
    </table>
    <a type="button" class="btn btn-success" href="<?php echo e(url()->previous()); ?>"><i class="fas fa-arrow-left"></i> Kembali</a>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/dataTables.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/responsive.bootstrap4.min.css')); ?>">
    <style>
        .tabb {
            display: inline-block;
            width: :200px
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/responsive.bootstrap4.min.js')); ?>"></script>
    <script>
        $(function() {
            $("#example1").DataTable({
                "responsive": true,
                "lengthChange": false,
                "autoWidth": false,
            })
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\coding\laragon\www\051-Arief-Rahman\elibrary\resources\views/admin/categories/show.blade.php ENDPATH**/ ?>